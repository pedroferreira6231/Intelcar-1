# Intelcar 2.7

Projeto limpo para testar no Android com Acode ou Chrome.

## Ficheiros

- `index.html`
- `css/style.css`
- `js/app.js`

## Como usar no GitHub

1. Criar um repositório novo.
2. Extrair este ZIP no telemóvel.
3. Enviar os ficheiros extraídos para o GitHub.
4. O ficheiro `index.html` deve ficar na raiz do repositório.

## Como testar

Abrir `index.html` no Chrome e dar permissão ao GPS e ao microfone.
