let gpsWatchId = null;
let currentSpeed = 0;
let tripActive = false;
let recognition = null;
let waitingCommand = false;

function speak(text) {
  try {
    window.speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = 'pt-PT';
    msg.rate = 1;
    msg.pitch = 1;
    window.speechSynthesis.speak(msg);
  } catch (e) {
    console.log('Erro na voz:', e);
  }
}

function setStatus(text) {
  document.getElementById('status').innerText = text;
}

function startTrip() {
  tripActive = true;
  setStatus('Viagem iniciada');
  speak('Intelcar ativo. Boa viagem.');
  startGPS();
}

function stopTrip() {
  tripActive = false;
  setStatus('Parado');
  if (gpsWatchId !== null) {
    navigator.geolocation.clearWatch(gpsWatchId);
    gpsWatchId = null;
  }
  speak('Viagem parada.');
}

function startGPS() {
  if (!navigator.geolocation) {
    document.getElementById('gpsInfo').innerText = 'GPS não disponível neste telemóvel';
    speak('GPS não disponível neste telemóvel.');
    return;
  }

  if (gpsWatchId !== null) return;

  gpsWatchId = navigator.geolocation.watchPosition(
    function(pos) {
      let speedKmh = 0;

      if (pos.coords.speed !== null && !isNaN(pos.coords.speed)) {
        speedKmh = Math.max(0, pos.coords.speed * 3.6);
      }

      currentSpeed = speedKmh;
      document.getElementById('speed').innerText = Math.round(currentSpeed) + ' km/h';
      document.getElementById('gpsInfo').innerText =
        'GPS ativo | precisão: ' + Math.round(pos.coords.accuracy) + ' m';
    },
    function(error) {
      document.getElementById('gpsInfo').innerText = 'Erro GPS: ' + error.message;
      speak('Não consegui aceder ao GPS.');
    },
    {
      enableHighAccuracy: true,
      maximumAge: 1000,
      timeout: 15000
    }
  );
}

function startVoiceControl() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    speak('Este navegador não suporta reconhecimento de voz. Usa o Chrome.');
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = 'pt-PT';
  recognition.continuous = true;
  recognition.interimResults = false;

  recognition.onresult = function(event) {
    const text = event.results[event.results.length - 1][0].transcript.toLowerCase();
    console.log('Ouvi:', text);
    handleVoice(text);
  };

  recognition.onerror = function(event) {
    console.log('Erro microfone:', event.error);
  };

  recognition.onend = function() {
    // tenta manter ligado enquanto a página estiver aberta
    try {
      recognition.start();
    } catch (e) {}
  };

  try {
    recognition.start();
    setStatus('Microfone ligado');
    speak('Microfone ligado. Diz olá Intelcar.');
  } catch (e) {
    console.log('Erro ao iniciar microfone:', e);
  }
}

function handleVoice(text) {
  if (text.includes('olá intelcar') || text.includes('ola intelcar')) {
    waitingCommand = true;
    speak('Estou a ouvir.');
    return;
  }

  if (!waitingCommand) return;

  if (text.includes('velocidade')) {
    speak('Velocidade atual ' + Math.round(currentSpeed) + ' quilómetros por hora.');
    waitingCommand = false;
    return;
  }

  if (text.includes('abrir mapas') || text.includes('google maps')) {
    speak('A abrir mapas.');
    window.location.href = 'https://www.google.com/maps';
    waitingCommand = false;
    return;
  }

  if (text.includes('iniciar viagem')) {
    startTrip();
    waitingCommand = false;
    return;
  }

  if (text.includes('parar')) {
    stopTrip();
    waitingCommand = false;
    return;
  }

  speak('Não percebi o comando.');
  waitingCommand = false;
}
