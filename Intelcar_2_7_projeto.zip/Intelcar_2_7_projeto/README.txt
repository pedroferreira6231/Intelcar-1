INTELCAR 2.7 — PROJETO LIMPO

Ficheiros:
- index.html
- css/style.css
- js/app.js

Como testar no Android:
1. Extrair o ZIP.
2. Abrir a pasta no Acode.
3. Abrir o ficheiro index.html.
4. Testar no Chrome.
5. Dar permissão ao GPS e ao microfone.

Botões:
- Iniciar viagem: liga GPS e voz.
- Parar: para viagem e GPS.
- Testar voz: testa voz pt-PT.
- Ligar microfone: ativa comandos por voz.

Comandos:
- olá intelcar
- qual é a velocidade
- abrir mapas
- iniciar viagem
- parar

Nota:
Esta versão é de raiz, simples e limpa. Serve para testar antes de voltar a criar APK.
