let gpsWatchId = null;
let currentSpeed = 0;
let recognition = null;
let waitingCommand = false;
let tripActive = false;

function byId(id) {
  return document.getElementById(id);
}

function setStatus(text) {
  byId('status').innerText = text;
}

function speak(text) {
  try {
    window.speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = 'pt-PT';
    msg.rate = 1;
    msg.pitch = 1;
    window.speechSynthesis.speak(msg);
  } catch (error) {
    console.log('Erro na voz:', error);
  }
}

function testVoice() {
  speak('Intelcar dois ponto sete ativo.');
}

function startTrip() {
  tripActive = true;
  setStatus('Viagem iniciada');
  speak('Intelcar ativo. Boa viagem.');
  startGPS();
}

function stopTrip() {
  tripActive = false;
  setStatus('Parado');

  if (gpsWatchId !== null) {
    navigator.geolocation.clearWatch(gpsWatchId);
    gpsWatchId = null;
  }

  speak('Viagem parada.');
}

function startGPS() {
  if (!navigator.geolocation) {
    byId('gpsInfo').innerText = 'GPS nao disponivel neste telemovel';
    speak('GPS nao disponivel neste telemovel.');
    return;
  }

  if (gpsWatchId !== null) return;

  gpsWatchId = navigator.geolocation.watchPosition(
    function(pos) {
      let speedKmh = 0;

      if (pos.coords.speed !== null && !isNaN(pos.coords.speed)) {
        speedKmh = Math.max(0, pos.coords.speed * 3.6);
      }

      currentSpeed = speedKmh;
      byId('speed').innerText = Math.round(currentSpeed) + ' km/h';
      byId('gpsInfo').innerText = 'GPS ativo | precisao: ' + Math.round(pos.coords.accuracy) + ' m';
    },
    function(error) {
      byId('gpsInfo').innerText = 'Erro GPS: ' + error.message;
      speak('Nao consegui aceder ao GPS.');
    },
    {
      enableHighAccuracy: true,
      maximumAge: 1000,
      timeout: 15000
    }
  );
}

function startVoiceControl() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    speak('Este navegador nao suporta reconhecimento de voz. Usa o Chrome.');
    return;
  }

  if (recognition !== null) {
    try { recognition.stop(); } catch (error) {}
    recognition = null;
  }

  recognition = new SpeechRecognition();
  recognition.lang = 'pt-PT';
  recognition.continuous = true;
  recognition.interimResults = false;

  recognition.onresult = function(event) {
    const text = event.results[event.results.length - 1][0].transcript.toLowerCase();
    console.log('Ouvi:', text);
    handleVoice(text);
  };

  recognition.onerror = function(event) {
    console.log('Erro microfone:', event.error);
  };

  recognition.onend = function() {
    if (recognition !== null) {
      try { recognition.start(); } catch (error) {}
    }
  };

  try {
    recognition.start();
    setStatus('Microfone ligado');
    speak('Microfone ligado. Diz ola Intelcar.');
  } catch (error) {
    console.log('Erro ao iniciar microfone:', error);
  }
}

function handleVoice(text) {
  if (text.includes('ola intelcar') || text.includes('olá intelcar')) {
    waitingCommand = true;
    speak('Estou a ouvir.');
    return;
  }

  if (!waitingCommand) return;

  if (text.includes('velocidade')) {
    speak('Velocidade atual ' + Math.round(currentSpeed) + ' quilometros por hora.');
    waitingCommand = false;
    return;
  }

  if (text.includes('abrir mapas') || text.includes('google maps')) {
    openMaps();
    waitingCommand = false;
    return;
  }

  if (text.includes('iniciar viagem')) {
    startTrip();
    waitingCommand = false;
    return;
  }

  if (text.includes('parar')) {
    stopTrip();
    waitingCommand = false;
    return;
  }

  speak('Nao percebi o comando.');
  waitingCommand = false;
}

function openMaps() {
  speak('A abrir mapas.');
  window.location.href = 'https://www.google.com/maps';
}
