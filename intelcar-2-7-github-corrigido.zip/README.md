# Intelcar 2.7

Projeto HTML simples para testar a Intelcar no telemóvel antes de criar APK.

## O que contém

- `index.html` — página principal
- `css/style.css` — visual da aplicação
- `js/app.js` — GPS, voz, microfone e mapas
- `.github/workflows/pages.yml` — publica automaticamente no GitHub Pages

## Como colocar no GitHub pelo telemóvel

1. Extrair o ZIP no telemóvel.
2. Criar um repositório novo no GitHub.
3. Enviar estes ficheiros e pastas extraídos para o repositório:
   - `index.html`
   - `css`
   - `js`
   - `.github`
   - `README.md`
4. Não enviar o ZIP fechado como ficheiro principal do projeto.

## Como ativar o GitHub Pages

1. Abrir o repositório no GitHub.
2. Ir a **Settings**.
3. Ir a **Pages**.
4. Em **Build and deployment**, escolher **GitHub Actions**.
5. Guardar.
6. Abrir o separador **Actions** e confirmar se aparece o workflow **Publicar Intelcar 2.7**.

## Como testar

Depois de publicado no GitHub Pages, abrir o link no Chrome do Android.

Para GPS e microfone funcionarem melhor, usar o link `https://...github.io/...`, não abrir apenas o ficheiro local.

## Notas importantes

- Isto ainda não é APK.
- É uma versão limpa para teste no navegador.
- O microfone pode precisar de toque no botão por segurança do Android/Chrome.
- O GPS só funciona se deres permissão de localização.
